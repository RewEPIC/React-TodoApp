import { useState } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Square from './components/Square';
import Done from './page/Done';
import NotDone from './page/NotDone';
import Layout from './page/Layout';
import All from './page/All';


function App() {
  // const board = useState([
  //   '.','.','.',
  //   '.','.','.',
  //   '.','.','.',
  // ])
  // const [clicked, setClick] = useState('Nothing')
  // const handleClick = (i: number) => {
  //   setClick(`${i}`)
  // }
  // const squares = []
  // for (let i = 0; i < 9; i++) squares.push(<Square value={board[0][i]} onClick={() => handleClick(i)}/>)
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={ <Layout/> }>
          <Route path="/" element={<All/>}/>
          <Route path="done" element={<Done />} />
          <Route path="not-done" element={<NotDone />} />
        </Route>
      </Routes>
    </BrowserRouter>
    // <div className='App'>
    //   <div onClick={onClick}>+</div><div>-</div>
    //   {board.map((board) => 
    //   <Square>
    //     <div>{ board.id }</div>
    //     <button onClick={() => onDelete(board.id)}>DELETE</button>
    //     <button onClick={() => onDone(board.id)}>{ board.status }</button>
    //   </Square>)}
    // </div>
    // <div className="App">
    //   <div className='board-row'>{squares.slice(0,3)}</div>
    //   <div className='board-row'>{squares.slice(3,6)}</div>
    //   <div className='board-row'>{squares.slice(6,9)}</div>
    //   <div>Click { clicked } </div>
    // </div>
  )
}

export default App;
