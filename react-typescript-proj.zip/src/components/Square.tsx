import { Children, MouseEventHandler } from "react";

type props = {
    value?: String,
    onClick?: MouseEventHandler
    children?: React.ReactNode
}

function Square({ value, onClick, children }: props) {
    return (
        <button className="square" onClick={onClick}>
            { value }
            { children }
        </button>
    )
}
export default Square;