import { useContext } from "react";
import { BoardContext } from "./Layout";
import Square from "../components/Square";
import ListBoard from "./ListBoard";

const All = () => {
  return (<ListBoard status="All"></ListBoard>)
};

export default All;
