import ListBoard from "./ListBoard"


const Done = () => {
    return (<ListBoard status="Done"></ListBoard>)
}

export default Done