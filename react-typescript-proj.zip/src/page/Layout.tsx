import { createContext, useState } from "react";
import { Outlet, Link } from "react-router-dom";
import Square from "../components/Square";
import All from "./All";

interface BoardContext {
    board: Board[] | null
    setBoard: React.Dispatch<React.SetStateAction<Board[]>> | null
}
interface Board {
    id?: number;
    status?: string;
  }
export const BoardContext = createContext<BoardContext>({board:null,setBoard:null})
const Layout = () => {
    const [board,setBoard] = useState<Board[]>([])
    const onClick = () => {
        if (board && setBoard) setBoard((oldBoard) => [
          ...oldBoard,
          { id: board.length, status: "Not Done" },
        ])
      };
  return (
    
    <BoardContext.Provider value={{board, setBoard}}>
      <nav>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/done">Done</Link></li>
          <li><Link to="/not-done">Not Done</Link></li>
        </ul>
      </nav>
      <div onClick={onClick}>+</div>
      <Outlet />
    </BoardContext.Provider>
  )
};

export default Layout;