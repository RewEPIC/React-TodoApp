import { useContext } from "react";
import { BoardContext } from "./Layout";
import Square from "../components/Square";

interface Props {
    status: 'All' | 'Not Done' | 'Done'
}

const ListBoard = ({ status }: Props) => {
    const { board, setBoard } = useContext(BoardContext);
    const onDelete = (deleteId: any) => {
      if (board && setBoard) setBoard(board.filter((board) => board.id !== deleteId))
    };
    const onDone = (doneId: any) => {
      if (board && setBoard) {
        const newBoard = board.map((board) => board.id === doneId ? { ...board, status: "Done" } : board);
        setBoard(newBoard)
      }
    };
    return (<div>
      {board?.filter((board) => status === 'All' || board.status === status).map((board) => (
        <Square>
          <div>{board.id}</div>
          <button onClick={() => onDelete(board.id)}>DELETE</button>
          <button onClick={() => onDone(board.id)}>{board.status}</button>
        </Square>
      ))}
    </div>)
}

export default ListBoard