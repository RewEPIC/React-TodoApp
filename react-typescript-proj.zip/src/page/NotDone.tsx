
import ListBoard from "./ListBoard"


const NotDone = () => {
    return (<ListBoard status="Not Done"></ListBoard>)
}

export default NotDone